import React, { useState } from 'react';

function App() {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState([]);
    const [apiKey, setApiKey] = useState('');

    const handleChange = (event) => {
        setQuery(event.target.value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await fetch(`https://localhost:7225/api/Search?query=${encodeURIComponent(query)}}`);
            const data = await response.json();            
            setResults(data.webPages.value);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    return (
        <div>
            <h1>Bing Search App</h1>
            <form onSubmit={handleSubmit}>
                Search Text <input type="text" value={query} onChange={handleChange} />
                <button type="submit">Search</button>
            </form>
            <div>
                <h2>Search Results:</h2>
                <ul>
                  
                    {results.map((result, index) => (
                      
                        <li key={index}>
                            <a href={result.id}>{result.name}</a>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}

export default App;
